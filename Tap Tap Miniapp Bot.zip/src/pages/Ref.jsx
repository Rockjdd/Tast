import React from "react";

const Ref = () => {
  return <div>This Is Not Full Code, dm on telegram @ETBCEO For Full Code. We can clone Hamster Tapswap Any miniapp bot</div>;
};

export default Ref;
